// pages/index.jsx
// LocalWorship.ie — homepage with client-side live filtering (search + preset dropdowns)

import React, { useEffect, useMemo, useState } from 'react'
import { GoogleMap, Marker, useLoadScript } from '@react-google-maps/api'

/*
  This file implements:
  - Live client-side search (searchTerm) that matches name, faith, area, address
  - Preset dropdown filters: Faith, Area, Service Type
  - Clear All button
  - Sticky filter bar (desktop) placed above listings
  - Map markers synchronized with filtered results
  - Uses fallback sample data (no Firebase required)
*/

const Button = ({ children, className = '', ...props }) => (
  <button {...props} className={`bg-blue-600 text-white px-4 py-2 rounded-xl hover:bg-blue-700 transition ${className}`}>
    {children}
  </button>
)

const Card = ({ children, className = '' }) => (
  <div className={`bg-white shadow rounded-2xl ${className}`}>{children}</div>
)
const CardContent = ({ children, className = '' }) => <div className={`p-4 ${className}`}>{children}</div>

// Preset dropdown options
const PRESET_AREAS = ['All', 'Dublin 1', 'Dublin 2', 'Dublin 3', 'Dublin 4', 'Dublin 6', 'Dublin 7', 'Dublin 8', 'South County Dublin', 'North County Dublin']
const PRESET_FAITHS = ['All', 'Christian (Catholic)', 'Christian (Protestant)', 'Muslim', 'Jewish', 'Hindu', 'Buddhist', 'Sikh', 'Other']
const PRESET_SERVICES = ['All', 'Sunday Service', 'Friday Prayers', 'Sabbath Service', 'Daily Mass', 'Meditation / Study Group']

// Sample fallback listings (added serviceType field)
const FALLBACK_LISTINGS = [
  { id: 'st-pats', name: "St. Patrick's Cathedral", faith: 'Christian (Protestant)', area: 'Dublin 8', address: "St Patrick's Close, Dublin 8", lat: 53.3390, lng: -6.2711, serviceType: 'Sunday Service' },
  { id: 'dublin-mosque', name: 'Dublin Mosque & Islamic Centre', faith: 'Muslim', area: 'Dublin 1', address: 'Abbey Street, Dublin 1', lat: 53.3498, lng: -6.2680, serviceType: 'Friday Prayers' },
  { id: 'hindu-centre', name: 'Hindu Cultural Centre', faith: 'Hindu', area: 'Dublin 2', address: 'Drury Street, Dublin 2', lat: 53.3445, lng: -6.2592, serviceType: 'Meditation / Study Group' },
  { id: 'christchurch', name: 'Christ Church Cathedral', faith: 'Christian (Anglican)', area: 'Dublin 8', address: 'Christchurch Place, Dublin 8', lat: 53.3438, lng: -6.2715, serviceType: 'Sunday Service' },
]

const FALLBACK_EVENTS = [
  { id: 'easter-mass', title: 'Easter Mass', date: '2026-04-06T10:00:00', location: "St. Patrick's Cathedral" },
  { id: 'ramadan-iftar', title: 'Ramadan Iftar', date: '2026-04-01T19:00:00', location: 'Dublin Mosque & Islamic Centre' },
]

export default function Home() {
  const [listings, setListings] = useState(FALLBACK_LISTINGS)
  const [events, setEvents] = useState(FALLBACK_EVENTS)

  // Search & filter state
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedFaith, setSelectedFaith] = useState('All')
  const [selectedArea, setSelectedArea] = useState('All')
  const [selectedService, setSelectedService] = useState('All')

  // Map key guard
  const mapsKey = (typeof process !== 'undefined' && process.env && process.env.NEXT_PUBLIC_GOOGLE_MAPS_KEY)
    ? process.env.NEXT_PUBLIC_GOOGLE_MAPS_KEY
    : (typeof window !== 'undefined' ? window.NEXT_PUBLIC_GOOGLE_MAPS_KEY || '' : '')
  const { isLoaded } = useLoadScript({ googleMapsApiKey: mapsKey })

  // Live filtered results (memoized)
  const filteredListings = useMemo(() => {
    const q = (searchTerm || '').trim().toLowerCase()

    return listings.filter((l) => {
      if (selectedFaith && selectedFaith !== 'All') {
        if ((l.faith || '').toLowerCase() !== selectedFaith.toLowerCase()) return false
      }
      if (selectedArea && selectedArea !== 'All') {
        if ((l.area || '').toLowerCase() !== selectedArea.toLowerCase()) return false
      }
      if (selectedService && selectedService !== 'All') {
        if ((l.serviceType || '').toLowerCase() !== selectedService.toLowerCase()) return false
      }
      if (!q) return true
      const hay = `${l.name} ${l.faith} ${l.area} ${l.address}`.toLowerCase()
      return hay.includes(q)
    })
  }, [listings, searchTerm, selectedFaith, selectedArea, selectedService])

  function clearAll() {
    setSearchTerm('')
    setSelectedFaith('All')
    setSelectedArea('All')
    setSelectedService('All')
  }

  const activeFilters = []
  if (selectedFaith && selectedFaith !== 'All') activeFilters.push(selectedFaith)
  if (selectedArea && selectedArea !== 'All') activeFilters.push(selectedArea)
  if (selectedService && selectedService !== 'All') activeFilters.push(selectedService)

  return (
    <main className="min-h-screen bg-[rgb(249,245,241)] text-gray-800">
      <header className="max-w-6xl mx-auto py-6 px-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-[rgba(220,220,215,0.6)] flex items-center justify-center">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" className="w-6 h-6 text-gray-700">
              <path fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" d="M3 12c4-6 10 0 12 0s2-2 6-6" />
            </svg>
          </div>
          <div>
            <div className="font-semibold text-lg">LocalWorship.ie</div>
            <div className="text-xs text-gray-500">Places of worship • Dublin</div>
          </div>
        </div>
      </header>

      <section className="max-w-6xl mx-auto px-6 pt-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
          <div>
            <h1 className="text-4xl md:text-5xl font-serif leading-tight">Find a place of peace and prayer near you</h1>
            <p className="mt-4 text-gray-600">Discover churches, mosques, temples, synagogues, and more across Dublin.</p>
          </div>
        </div>
      </section>
    </main>
  )
}
